    </div><!-- /.container -->
    <footer>
        <p>&copy; <?php echo date('Y'); ?> SIMADIK - Sistem Manajemen Pelaporan</p>
    </footer>
</body>
</html>
