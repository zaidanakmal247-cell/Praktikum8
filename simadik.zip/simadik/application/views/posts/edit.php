<?php $this->load->view('posts/header'); ?>

<div class="card">
    <a href="<?php echo base_url('laporan'); ?>" class="btn btn-primary back-link">← Kembali</a>
    <h2 style="margin-bottom:24px;">✏️ Edit Laporan</h2>

    <form action="<?php echo base_url('laporan/update/' . $post->id); ?>" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Judul Laporan</label>
            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($post->title); ?>">
        </div>
        <div class="form-group">
            <label for="author">Penulis</label>
            <input type="text" id="author" name="author" value="<?php echo htmlspecialchars($post->author); ?>">
        </div>
        <div class="form-group">
            <label for="article">Isi Laporan</label>
            <textarea id="article" name="article"><?php echo htmlspecialchars($post->article); ?></textarea>
        </div>
        <div class="form-group">
            <label for="image">Ganti Gambar (opsional)</label>
            <?php if($post->image_url): ?>
                <div style="margin-bottom:10px;">
                    <img src="<?php echo base_url($post->image_url); ?>" alt="gambar" style="max-width:150px; border-radius:6px;">
                    <p style="font-size:0.85em; color:#888; margin-top:4px;">Gambar saat ini</p>
                </div>
            <?php endif; ?>
            <input type="file" id="image" name="image" accept="image/jpg,image/jpeg,image/png">
            <small style="color:#888;">Format: JPG, JPEG, PNG. Maks: 2MB</small>
        </div>
        <button type="submit" class="btn btn-warning">🔄 Perbarui Laporan</button>
    </form>
</div>

<?php $this->load->view('posts/footer'); ?>
