<?php $this->load->view('posts/header'); ?>

<div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h2>📋 Daftar Laporan</h2>
        <a href="<?php echo base_url('laporan/create'); ?>" class="btn btn-success">+ Buat Laporan</a>
    </div>

    <?php if(empty($posts)): ?>
        <div class="text-center" style="padding:40px;">
            <p style="font-size:18px; color:#666;">Belum ada laporan. Buat laporan pertama Anda!</p>
            <a href="<?php echo base_url('laporan/create'); ?>" class="btn btn-primary" style="margin-top:20px;">Buat Laporan</a>
        </div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th style="width:50px;">No</th>
                    <th style="width:90px;">Gambar</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th style="width:220px;">Isi Singkat</th>
                    <th style="width:180px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($posts as $i => $post): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td>
                        <?php if($post->image_url): ?>
                            <img src="<?php echo base_url($post->image_url); ?>" alt="gambar" class="post-image">
                        <?php else: ?>
                            <span style="color:#999;">-</span>
                        <?php endif; ?>
                    </td>
                    <td><strong><?php echo htmlspecialchars($post->title); ?></strong></td>
                    <td><?php echo htmlspecialchars($post->author); ?></td>
                    <td>
                        <div class="article-preview">
                            <?php echo htmlspecialchars(substr($post->article, 0, 100)); ?>
                            <?php echo strlen($post->article) > 100 ? '...' : ''; ?>
                        </div>
                    </td>
                    <td>
                        <div class="actions">
                            <a href="<?php echo base_url('laporan/show/' . $post->id); ?>" class="btn btn-info">Lihat</a>
                            <a href="<?php echo base_url('laporan/edit/' . $post->id); ?>" class="btn btn-warning">Edit</a>
                            <a href="<?php echo base_url('laporan/delete/' . $post->id); ?>"
                               class="btn btn-danger"
                               onclick="return confirm('Yakin ingin menghapus laporan ini?');">Hapus</a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php $this->load->view('posts/footer'); ?>
