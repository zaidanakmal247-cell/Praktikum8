<?php $this->load->view('posts/header'); ?>

<div class="card">
    <a href="<?php echo base_url('laporan'); ?>" class="btn btn-primary back-link">← Kembali</a>
    <h2 style="margin-bottom:24px;">➕ Buat Laporan Baru</h2>

    <form action="<?php echo base_url('laporan/store'); ?>" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Judul Laporan *</label>
            <input type="text" id="title" name="title" placeholder="Masukkan judul laporan" required>
        </div>
        <div class="form-group">
            <label for="author">Penulis *</label>
            <input type="text" id="author" name="author" placeholder="Nama penulis" required>
        </div>
        <div class="form-group">
            <label for="article">Isi Laporan *</label>
            <textarea id="article" name="article" placeholder="Tulis isi laporan di sini..." required></textarea>
        </div>
        <div class="form-group">
            <label for="image">Gambar (opsional)</label>
            <input type="file" id="image" name="image" accept="image/jpg,image/jpeg,image/png">
            <small style="color:#888;">Format: JPG, JPEG, PNG. Maks: 2MB</small>
        </div>
        <button type="submit" class="btn btn-success">💾 Simpan Laporan</button>
    </form>
</div>

<?php $this->load->view('posts/footer'); ?>
