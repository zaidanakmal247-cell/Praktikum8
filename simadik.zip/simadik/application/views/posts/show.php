<?php $this->load->view('posts/header'); ?>

<div class="card">
    <a href="<?php echo base_url('laporan'); ?>" class="btn btn-primary back-link">← Kembali</a>

    <h2 style="margin-bottom:8px;"><?php echo htmlspecialchars($post->title); ?></h2>
    <p style="color:#888; margin-bottom:20px; font-size:0.9em;">
        ✍️ <?php echo htmlspecialchars($post->author); ?> &nbsp;|&nbsp;
        📅 <?php echo date('d F Y, H:i', strtotime($post->created_at)); ?>
    </p>

    <?php if($post->image_url): ?>
        <img src="<?php echo base_url($post->image_url); ?>" alt="<?php echo htmlspecialchars($post->title); ?>" class="post-detail-image">
    <?php endif; ?>

    <div style="margin-top:20px; line-height:1.8; color:#333; white-space:pre-wrap;">
        <?php echo htmlspecialchars($post->article); ?>
    </div>

    <div style="margin-top:30px; display:flex; gap:10px;">
        <a href="<?php echo base_url('laporan/edit/' . $post->id); ?>" class="btn btn-warning">✏️ Edit</a>
        <a href="<?php echo base_url('laporan/delete/' . $post->id); ?>"
           class="btn btn-danger"
           onclick="return confirm('Yakin ingin menghapus laporan ini?');">🗑️ Hapus</a>
    </div>
</div>

<?php $this->load->view('posts/footer'); ?>
