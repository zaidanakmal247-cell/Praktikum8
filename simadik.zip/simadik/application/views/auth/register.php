<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - SIMADIK</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .auth-card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2);
            padding: 50px 40px;
            width: 100%;
            max-width: 420px;
        }
        .logo { text-align: center; margin-bottom: 30px; }
        .logo h1 { font-size: 2.2em; color: #667eea; font-weight: 700; letter-spacing: 2px; }
        .logo p { color: #888; font-size: 0.9em; margin-top: 4px; }
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 0.88em; }
        .alert-error { background: #f8d7da; color: #721c24; border-left: 4px solid #dc3545; }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 600; color: #444; font-size: 0.9em; }
        .form-group input {
            width: 100%; padding: 12px 16px;
            border: 2px solid #e0e0e0; border-radius: 8px;
            font-size: 14px; transition: border-color 0.3s;
        }
        .form-group input:focus { outline: none; border-color: #667eea; }
        .hint { font-size: 0.78em; color: #aaa; margin-top: 4px; }
        .btn-submit {
            width: 100%; padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; border: none; border-radius: 8px;
            font-size: 15px; font-weight: 600; cursor: pointer;
            transition: all 0.3s; letter-spacing: 0.5px;
        }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(102,126,234,0.4); }
        .text-center { text-align: center; margin-top: 20px; font-size: 0.9em; color: #888; }
        .text-center a { color: #667eea; text-decoration: none; font-weight: 600; }
        .text-center a:hover { text-decoration: underline; }
        .divider { border: none; border-top: 1px solid #eee; margin: 24px 0; }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="logo">
            <h1>SIMADIK</h1>
            <p>Daftar Akun Baru</p>
        </div>

        <?php if($this->session->flashdata('error')): ?>
            <div class="alert alert-error">✗ <?php echo $this->session->flashdata('error'); ?></div>
        <?php endif; ?>

        <form action="<?php echo base_url('auth/do_register'); ?>" method="POST">
            <div class="form-group">
                <label for="nama">Nama Lengkap</label>
                <input type="text" id="nama" name="nama" placeholder="Nama lengkap Anda" required autofocus>
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="Username unik Anda" required minlength="3">
                <div class="hint">Minimal 3 karakter, tidak boleh sama dengan yang lain.</div>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Buat password" required minlength="6">
                <div class="hint">Minimal 6 karakter.</div>
            </div>
            <div class="form-group">
                <label for="konfirmasi_password">Konfirmasi Password</label>
                <input type="password" id="konfirmasi_password" name="konfirmasi_password" placeholder="Ulangi password" required>
            </div>
            <button type="submit" class="btn-submit">Daftar</button>
        </form>

        <hr class="divider">
        <div class="text-center">
            Sudah punya akun? <a href="<?php echo base_url('login'); ?>">Login di sini</a>
        </div>
    </div>
</body>
</html>
