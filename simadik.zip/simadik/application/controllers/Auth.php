<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('form_validation', 'session'));
    }

    public function index()
    {
        // Redirect ke laporan jika sudah login
        if ($this->session->userdata('user_id')) {
            redirect('laporan');
        }
        redirect('login');
    }

    public function login()
    {
        if ($this->session->userdata('user_id')) {
            redirect('laporan');
        }

        $data['title'] = 'Login';
        $this->load->view('auth/login', $data);
    }

    public function do_login()
    {
        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('login');
            return;
        }

        $username = $this->input->post('username', TRUE);
        $password = $this->input->post('password', TRUE);

        $user = $this->User_model->get_by_username($username);

        if ($user && password_verify($password, $user->password)) {
            $this->session->set_userdata(array(
                'user_id'  => $user->id,
                'username' => $user->username,
                'nama'     => $user->nama
            ));
            $this->session->set_flashdata('success', 'Selamat datang, ' . $user->nama . '!');
            redirect('laporan');
        } else {
            $this->session->set_flashdata('error', 'Username atau password salah!');
            redirect('login');
        }
    }

    public function register()
    {
        if ($this->session->userdata('user_id')) {
            redirect('laporan');
        }

        $data['title'] = 'Register';
        $this->load->view('auth/register', $data);
    }

    public function do_register()
    {
        $this->form_validation->set_rules('nama', 'Nama Lengkap', 'required|trim|max_length[100]');
        $this->form_validation->set_rules('username', 'Username', 'required|trim|min_length[3]|max_length[50]|is_unique[users.username]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('konfirmasi_password', 'Konfirmasi Password', 'required|matches[password]');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('register');
            return;
        }

        $data = array(
            'nama'       => $this->input->post('nama', TRUE),
            'username'   => $this->input->post('username', TRUE),
            'password'   => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
            'created_at' => date('Y-m-d H:i:s')
        );

        if ($this->User_model->insert($data)) {
            $this->session->set_flashdata('success', 'Registrasi berhasil! Silakan login.');
            redirect('login');
        } else {
            $this->session->set_flashdata('error', 'Gagal registrasi. Coba lagi.');
            redirect('register');
        }
    }

    public function logout()
    {
        $this->session->unset_userdata(array('user_id', 'username', 'nama'));
        $this->session->sess_destroy();
        $this->session->set_flashdata('success', 'Anda berhasil logout.');
        redirect('login');
    }
}
