<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Post_model');
        $this->load->helper(array('url', 'form'));
        $this->load->library(array('form_validation', 'upload', 'session'));
        $this->_cek_login();
    }

    private function _cek_login()
    {
        if (!$this->session->userdata('user_id')) {
            $this->session->set_flashdata('error', 'Silakan login terlebih dahulu.');
            redirect('login');
        }
    }

    public function index()
    {
        $data['posts'] = $this->Post_model->get_all();
        $data['title'] = 'Semua Laporan';
        $this->load->view('posts/index', $data);
    }

    public function create()
    {
        $data['title'] = 'Buat Laporan Baru';
        $this->load->view('posts/create', $data);
    }

    public function store()
    {
        $this->form_validation->set_rules('title', 'Judul', 'required|max_length[255]');
        $this->form_validation->set_rules('author', 'Penulis', 'required|max_length[255]');
        $this->form_validation->set_rules('article', 'Isi Laporan', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('laporan/create');
            return;
        }

        $data = array(
            'title'      => $this->input->post('title'),
            'author'     => $this->input->post('author'),
            'article'    => $this->input->post('article'),
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        );

        if (!empty($_FILES['image']['name'])) {
            $upload_result = $this->_upload_image();
            if ($upload_result['status']) {
                $data['image'] = 'posts/' . $upload_result['file_name'];
            } else {
                $this->session->set_flashdata('error', $upload_result['error']);
                redirect('laporan/create');
                return;
            }
        }

        $post_id = $this->Post_model->insert($data);

        if ($post_id) {
            $this->session->set_flashdata('success', 'Laporan berhasil ditambahkan!');
            redirect('laporan');
        } else {
            $this->session->set_flashdata('error', 'Gagal menyimpan laporan.');
            redirect('laporan/create');
        }
    }

    public function show($id)
    {
        $post = $this->Post_model->get_by_id($id);
        if (!$post) { show_404(); return; }
        $data['post']  = $post;
        $data['title'] = $post->title;
        $this->load->view('posts/show', $data);
    }

    public function edit($id)
    {
        $post = $this->Post_model->get_by_id($id);
        if (!$post) { show_404(); return; }
        $data['post']  = $post;
        $data['title'] = 'Edit Laporan';
        $this->load->view('posts/edit', $data);
    }

    public function update($id)
    {
        if (!$this->Post_model->exists($id)) { show_404(); return; }

        $this->form_validation->set_rules('title', 'Judul', 'max_length[255]');
        $this->form_validation->set_rules('author', 'Penulis', 'max_length[255]');

        if ($this->form_validation->run() === FALSE) {
            $this->session->set_flashdata('error', validation_errors());
            redirect('laporan/edit/' . $id);
            return;
        }

        $data = array('updated_at' => date('Y-m-d H:i:s'));

        if ($this->input->post('title'))   $data['title']   = $this->input->post('title');
        if ($this->input->post('author'))  $data['author']  = $this->input->post('author');
        if ($this->input->post('article')) $data['article'] = $this->input->post('article');

        if (!empty($_FILES['image']['name'])) {
            $old_post = $this->Post_model->get_by_id($id);
            if ($old_post->image) {
                $old = './uploads/' . $old_post->image;
                if (file_exists($old)) unlink($old);
            }
            $upload_result = $this->_upload_image();
            if ($upload_result['status']) {
                $data['image'] = 'posts/' . $upload_result['file_name'];
            } else {
                $this->session->set_flashdata('error', $upload_result['error']);
                redirect('laporan/edit/' . $id);
                return;
            }
        }

        if ($this->Post_model->update($id, $data)) {
            $this->session->set_flashdata('success', 'Laporan berhasil diperbarui!');
            redirect('laporan');
        } else {
            $this->session->set_flashdata('error', 'Gagal memperbarui laporan.');
            redirect('laporan/edit/' . $id);
        }
    }

    public function delete($id)
    {
        $post = $this->Post_model->get_by_id($id);
        if (!$post) {
            $this->session->set_flashdata('error', 'Laporan tidak ditemukan.');
            redirect('laporan');
            return;
        }

        if ($post->image) {
            $path = './uploads/' . $post->image;
            if (file_exists($path)) unlink($path);
        }

        if ($this->Post_model->delete($id)) {
            $this->session->set_flashdata('success', 'Laporan berhasil dihapus!');
        } else {
            $this->session->set_flashdata('error', 'Gagal menghapus laporan.');
        }
        redirect('laporan');
    }

    private function _upload_image()
    {
        $upload_path = './uploads/posts/';
        if (!is_dir($upload_path)) mkdir($upload_path, 0777, true);

        $original_name  = $_FILES['image']['name'];
        $sanitized_name = preg_replace('/[^A-Za-z0-9._-]/', '_', $original_name);
        $file_name      = time() . '_' . $sanitized_name;

        $config['upload_path']   = $upload_path;
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size']      = 2048;
        $config['file_name']     = $file_name;
        $config['overwrite']     = FALSE;

        $this->upload->initialize($config);

        if ($this->upload->do_upload('image')) {
            return array('status' => TRUE, 'file_name' => $this->upload->data()['file_name']);
        } else {
            return array('status' => FALSE, 'error' => $this->upload->display_errors('', ''));
        }
    }
}
